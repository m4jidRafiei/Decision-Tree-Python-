from p_decision_tree import DecisionTree

__name__ = 'p_decision_tree'
__version__ = '0.0.2'
__doc__ = "Visual Decision Tree Based on Categorical Attributes"
__author__ = 'Majid Rafiei'
__author_email__ = 'majid.rafiei@pads.rwth-aachen.de'
__maintainer__ = 'Majid Rafiei'
__maintainer_email__ = "majid.rafiei@pads.rwth-aachen.de"
